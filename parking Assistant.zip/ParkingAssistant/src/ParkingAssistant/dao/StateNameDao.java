/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParkingAssistant.dao;

import ParkingAssistant.dbutil.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

/**
 *
 * @author HP
 */
public class StateNameDao {
    public static HashMap<String,String> getAllStateId() throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("select * from statename");
        
        HashMap<String,String> categoris = new HashMap<>();
        while(rs.next())
        {
            categoris.put(rs.getString(1),rs.getString(2) );
        }
        return categoris;
        
    }
    
    public static HashMap<String,String> getAllCityId(String stateid) throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("select * from statecity where state_id=?");
       ps.setString(1,stateid);
       ResultSet rs = ps.executeQuery();
        
        
        HashMap<String,String> cities = new HashMap<>();
        while(rs.next())
        {
            cities.put(rs.getString(2),rs.getString(3) );
        }
        return cities;
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  /*  public static HashMap<String,String> getAllStateName() throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("select * from statename");
        
        HashMap<String,String> statename = new HashMap<>();
        while(rs.next())
        {
            statename.put(rs.getString(1),rs.getString(2) );
        }
        return statename;
        
    }
    /*public static ArrayList<String> getCityName(String stateid) throws SQLException
{
 Connection conn = DBConnection.getConnection();
 PreparedStatement ps=conn.prepareStatement("select city_id from statecity where state_id=?");
 ps.setString(1, stateid);
 ResultSet rs = ps.executeQuery();
 ArrayList<String> cityid = new ArrayList<>();
        while(rs.next())
        {
            cityid.add(rs.getString(1) );
        }
        return cityid;
     
}*/
   /* public static ArrayList<String> getAllStateName() throws SQLException
    {
        ArrayList<String> allState = new ArrayList<>();
        Connection conn = DBConnection.getConnection();
        Statement st=conn.createStatement();
     ResultSet rs = st.executeQuery("select state_name from stateName");
        while(rs.next())
        {
          allState.add(rs.getString(1));
        }
        return allState;   
    }*/
    /*public static ArrayList<String> getCityName(String sname) throws SQLException
    {
        ArrayList<String> allCity = new ArrayList<>();
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("select city_name from StateWithCity where state_name=?");
        ps.setString(1, sname);
        ResultSet rs = ps.executeQuery();
        while(rs.next())
        {
            String cityName = rs.getString(1);
            allCity.add(cityName);
            
        }
        return allCity;
        
    }
    public static HashMap<String,String> getAllCityName(String stateid) throws SQLException
{
 Connection conn = DBConnection.getConnection();
 PreparedStatement ps=conn.prepareStatement("select * from statecity where state_id=?");
 ps.setString(1, stateid);
 ResultSet rs = ps.executeQuery();
 HashMap<String,String> cityid = new HashMap<>();
        while(rs.next())
        {
           cityid.put(rs.getString(2),rs.getString(3) );
        }
        return cityid;
     
}
    public static int getPlaceCount(String cname) throws SQLException
    {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("select count(*) from CityWithPlace where city_name=?");
        ps.setString(1, cname);
        int placeno = ps.executeUpdate();
        return placeno;
    }
    public static ArrayList<String> getPlaceName(String cname) throws SQLException
    {
        ArrayList<String> allplace = new ArrayList<>();
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("select place_name from CityWithPlace where city_name=?");
        ps.setString(1, cname);
        ResultSet rs = ps.executeQuery();
        while(rs.next())
        {
            String placeName = rs.getString(1);
            allplace.add(placeName);
            
        }
        return allplace;
        
    }*/
    public static String getParkingStatus() throws SQLException
    {
        String status;
        Connection conn = DBConnection.getConnection();
        System.out.println("hiii");
        PreparedStatement ps = conn.prepareStatement("select * from parkingsatus ");
        ResultSet rs = ps.executeQuery();
        if(rs.next())
        {
            
            status = rs.getString(2);
            return status;
        }
        return null;
    }
    
}
