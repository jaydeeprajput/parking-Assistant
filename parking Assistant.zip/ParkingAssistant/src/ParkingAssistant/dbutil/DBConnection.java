/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParkingAssistant.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBConnection {
    private static Connection conn;
    static {
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@//DESKTOP-RKUTSU9:1521/XE","parking","jaydeep");
            JOptionPane.showMessageDialog(null,"Connected Successfully to the database","Success!",JOptionPane.INFORMATION_MESSAGE);
        
        }
        catch(ClassNotFoundException ex)
        {
            JOptionPane.showMessageDialog(null,"Error in DriverManager Loading","Unsuccessful!!",JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
        catch(SQLException sq)
        {
            JOptionPane.showMessageDialog(null,"Error in DataBase","Unsuccessful!!",JOptionPane.ERROR_MESSAGE);
            sq.printStackTrace();
        }
    }
      public static Connection getConnection()
        {
            return conn;
        }
      public static void closeConnection()
      {
          try{
         conn.close();
      }
          catch(SQLException sq)
        {
            JOptionPane.showMessageDialog(null,"Error in DataBase","Unsuccessful!!",JOptionPane.ERROR_MESSAGE);
            sq.printStackTrace();
        }
          
      
      }
   }
