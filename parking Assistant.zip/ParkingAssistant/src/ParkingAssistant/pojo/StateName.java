/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParkingAssistant.pojo;

/**
 *
 * @author HP
 */
public class StateName {
    private static String stateName;
        private static String cityName;
        private static String placeName;
        private static String parkingStatus;

    public static void setPlaceName(String placeName) {
        StateName.placeName = placeName;
    }

    public static String getPlaceName() {
        return placeName;
    }

    public static String getCityName() {
        return cityName;
    }

    public static void setCityName(String cityName) {
        StateName.cityName = cityName;
    }
    

    public static String getStateName() {
        return stateName;
    }

    public static void setStateName(String stateName) {
        StateName.stateName = stateName;
    }
    
}
